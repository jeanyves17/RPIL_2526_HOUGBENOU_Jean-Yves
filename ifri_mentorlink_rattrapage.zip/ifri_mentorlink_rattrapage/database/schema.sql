-- ============================================
-- IFRI_MentorLink - Rattrapage - Schéma simplifié
-- ============================================

DROP TABLE IF EXISTS mentors;

CREATE TABLE mentors (
    id               SERIAL PRIMARY KEY,
    nom              VARCHAR(100) NOT NULL,
    matieres         TEXT[] NOT NULL,       -- ex: {'Python','Algorithmique'}
    disponibilites   TEXT[] NOT NULL,       -- ex: {'Lundi 14:00','Mercredi 10:00'}
    filiere          VARCHAR(50),           -- IA, IM, GL, SE_IoT, SI
    format_mentorat  VARCHAR(20) CHECK (format_mentorat IN ('présentiel','en ligne','les deux'))
);

-- Jeu de données (3 mentors minimum imposé par le sujet)
INSERT INTO mentors (nom, matieres, disponibilites, filiere, format_mentorat) VALUES
('Mensah Kokou',
 ARRAY['Algorithmique','Python','Bases de données'],
 ARRAY['Lundi 14:00','Mercredi 10:00','Vendredi 16:00'],
 'GL', 'les deux'),

('Adjovi Rachelle',
 ARRAY['Mathématiques','Recherche Opérationnelle'],
 ARRAY['Mardi 09:00','Jeudi 15:00'],
 'IA', 'en ligne'),

('Gbaguidi Éric',
 ARRAY['SQL','Programmation C','Réseaux'],
 ARRAY['Lundi 08:00','Samedi 10:00'],
 'SE_IoT', 'présentiel');
